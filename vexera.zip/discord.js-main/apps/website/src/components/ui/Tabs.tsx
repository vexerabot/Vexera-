'use client';

export { Tabs, TabList, Tab, TabPanel } from 'react-aria-components';
