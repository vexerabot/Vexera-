'use client';

export { Collapsible, CollapsibleTrigger, CollapsibleContent } from '@radix-ui/react-collapsible';
