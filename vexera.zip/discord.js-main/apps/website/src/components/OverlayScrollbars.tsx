'use client';

import { OverlayScrollbars, ClickScrollPlugin } from 'overlayscrollbars';

OverlayScrollbars.plugin(ClickScrollPlugin);

export { OverlayScrollbarsComponent } from 'overlayscrollbars-react';
