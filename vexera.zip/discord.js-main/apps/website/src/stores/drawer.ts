import { atom } from 'jotai';

export const isDrawerOpenAtom = atom(false);
