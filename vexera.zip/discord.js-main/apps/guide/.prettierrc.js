/** @type {import('prettier').Config} */
module.exports = require('../../.prettierrc.json');
