module.exports = {
	plugins: {
		'@unocss/postcss': {},
	},
};
